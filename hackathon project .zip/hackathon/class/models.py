from django.db import models

# Create your models here.

class Lectures(models.Model):
    classroom = models.ForeignKey("dashboard.Classroom", on_delete=models.CASCADE)
    upload_date = models.DateTimeField(auto_now=True)
    topic = models.CharField(max_length=120)
    description = models.TextField()
    attachment = models.FileField(upload_to='lecture_attachments/', blank=True, null=True)
    slug = models.SlugField()

class SearchResult(models.Model):
    lecture = models.ForeignKey(Lectures, related_name='search_results', on_delete=models.CASCADE)
    title = models.CharField(max_length=255)
    link = models.URLField()
    snippet = models.TextField()

    def __str__(self):
        return self.title
    
