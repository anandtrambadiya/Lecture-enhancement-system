from django.urls import path
from . import views

urlpatterns = [
    path('<str:class_id>/', views.index),
    path('<str:class_id>/postlecture/', views.post_lecture),
    path('<str:class_id>/lecture/<str:lecture_slug>/', views.view_lecture),

]
