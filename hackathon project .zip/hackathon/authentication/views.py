from django.shortcuts import render, redirect
# from django.shortcuts import HttpResponse
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages

# Create your views here.
def register(request):
    if request.method == "POST":
        first_name = request.POST["fname"]
        last_name = request.POST["lname"]
        email = request.POST["email"]
        password = request.POST["password"]
        
        # Create a new user object
        u = User.objects.create_user(username=email, email=email)
        u.first_name = first_name
        u.last_name = last_name
        
        # Set the password securely
        u.set_password(password)
        u.save()

        # Authenticate and log in the newly registered user
        user = authenticate(username=email, password=password)
        if user is not None:
            login(request, user)

        return redirect('/dashboard/')
    else:
        return render(request, "authentication/register.html")

def login_view(request):
    if request.method == "POST":
        email = request.POST["email"]
        password = request.POST["password"]

        user = authenticate(username=email, password=password)

        if user is not None:
            login(request, user)
            return redirect('/dashboard/')
        else:
            messages.add_message(request, messages.ERROR, "Incorrect Login Credential")
            return redirect('/auth/login/')

    else:
        return render(request, "authentication/login.html")


def logout_view(request):
    logout(request)
    return redirect('/')