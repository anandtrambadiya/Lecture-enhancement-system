from django.shortcuts import render, redirect
import requests
from django.http import HttpResponse
from dashboard.models import Classroom, TeacherClassroom, StudentClassroom
from .models import Lectures, SearchResult
from django.template.defaultfilters import slugify


# Import NLTK libraries
import nltk
nltk.download('stopwords')
nltk.download('punkt')
nltk.download('wordnet')


from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer

def analyze_text(text):
    # Tokenize text into words
    tokens = word_tokenize(text.lower())

    # Remove stopwords and punctuation
    stop_words = set(stopwords.words('english'))
    filtered_tokens = [token for token in tokens if token.isalnum() and token not in stop_words]

    # Lemmatize tokens to their base forms
    lemmatizer = WordNetLemmatizer()
    lemmatized_tokens = [lemmatizer.lemmatize(token) for token in filtered_tokens]

    return lemmatized_tokens

def refine_tokens(tokens):
    # Remove tokens with a length less than 2
    refined_tokens = [token for token in tokens if len(token) > 1]

    return refined_tokens

def generate_search_query(topic, description, attachments):
    # Analyze topic, description, and attachments
    topic_tokens = analyze_text(topic)
    description_tokens = analyze_text(description)
    attachment_tokens = []

    # For demonstration purposes, assume attachments are paths to files
    for attachment_path in attachments:
        # Read text content from attachments (e.g., PDF, Word)
        with open(attachment_path, 'r') as file:
            attachment_text = file.read()
        attachment_tokens.extend(analyze_text(attachment_text))

    # Combine and refine tokens
    all_tokens = topic_tokens + description_tokens + attachment_tokens
    refined_tokens = refine_tokens(all_tokens)

    # Construct search query
    search_query = ' '.join(refined_tokens)
    # search_query += " open source project OR book OR academic paper OR youtube video"  # Additional filters

    return search_query


# Create your views here.
def index(request, class_id):
    classroom = Classroom.objects.get(join_code=class_id)
    lectures = Lectures.objects.filter(classroom=classroom)

    try:
        tc = TeacherClassroom.objects.get(classroom=classroom, user=request.user)
        role = "teacher"
    except TeacherClassroom.DoesNotExist:
        sc = StudentClassroom.objects.get(classroom=classroom, user=request.user)
        role = "student"

    return render(request, 'class/index.html', {
                'classroom': classroom,
                'lectures': lectures,
                'role': role,
    })

def post_lecture(request, class_id):
    classroom = Classroom.objects.get(join_code=class_id)
    if request.method == "POST":

        if 'attachment' in request.FILES:
            attachment = request.FILES['attachment']
        else:
            attachment = None

        lectures = Lectures.objects.create(
            topic=request.POST.get("topic"),
            description=request.POST.get("description"),
            classroom=classroom,
            attachment=attachment,
            slug=slugify(request.POST['topic']))


        # Handle form submission and save search results to the database (similar to the previous example)
        search_query = generate_search_query(request.POST.get("topic"),
                                             request.POST.get("description"),
                                             request.FILES.getlist("attachments"))

        # Fetch search results based on the generated search query
        search_results = fetch_search_results(search_query)

        # Save search results to the database
        for result in search_results:
            search_result = SearchResult.objects.create(
                lecture=lectures,
                title=result.get('title', ''),
                link=result.get('link', ''),
                snippet=result.get('snippet', '')
            )
            search_result.save()

        return redirect(f'/classroom/{class_id}')
    else:
        return render(request, 'class/post_lecture.html',
                  {'classroom': classroom})


def view_lecture(request, class_id, lecture_slug):
    classroom = Classroom.objects.get(join_code=class_id)
    lecture = Lectures.objects.get(classroom=classroom, slug=lecture_slug)
    search_results = lecture.search_results.all()

    return render(request, 'class/view_lecture.html',
                  {'lecture': lecture,
                   'classroom': classroom,
                   'search_results': search_results})


def fetch_search_results(search_query):
        API_KEY = "AIzaSyBofAqcrqI_kOjOK43v7I4DZt4s2ZiVMis"
        SEARCH_ENGINE_ID = "83f4858df030d4cfa"

        url = "https://www.googleapis.com/customsearch/v1"
        params = {
            'q': search_query,
            'key': API_KEY,
            'cx': SEARCH_ENGINE_ID,
            'num': 10,  # Number of search results to retrieve (adjust as needed)
            'filter': 1,  # Enable duplicate content filter
            'safe': 'high',  # Filter for high safe search results
            'lr': 'lang_en',  # Limit search results to English language
            'fields': 'items(title, link, snippet)'
        }
        response = requests.get(url, params=params)
        results = response.json().get('items', [])
        return results