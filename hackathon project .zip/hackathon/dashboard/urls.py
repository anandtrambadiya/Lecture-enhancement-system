from django.urls import path
from . import views

urlpatterns = [
    path('', views.base),
    path('dashboard/', views.view_all_classrooms),
    path('create_classroom/', views.create_classroom, name="create-classroom"),
    path('join_classroom/', views.join_classroom, name="join-classroom"),
]